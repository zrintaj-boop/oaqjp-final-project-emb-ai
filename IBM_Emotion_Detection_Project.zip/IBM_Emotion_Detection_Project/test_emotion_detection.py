"""Unit tests for EmotionDetection using a mocked Watson API response."""

import unittest
from unittest.mock import Mock, patch

from EmotionDetection import emotion_detector


class TestEmotionDetection(unittest.TestCase):
    """Verify score formatting, dominant emotion, and error handling."""

    @staticmethod
    def _watson_response(dominant):
        scores = {
            "anger": 0.05,
            "disgust": 0.05,
            "fear": 0.05,
            "joy": 0.05,
            "sadness": 0.05,
        }
        scores[dominant] = 0.8
        response = Mock()
        response.status_code = 200
        response.json.return_value = {
            "emotionPredictions": [{"emotion": scores}]
        }
        return response

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_joy(self, mocked_post):
        """Happy text yields joy when Watson returns a joy-dominant score."""
        mocked_post.return_value = self._watson_response("joy")
        result = emotion_detector("I am glad this worked!")
        self.assertEqual(result["dominant_emotion"], "joy")
        self.assertEqual(result["joy"], 0.8)

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_sadness(self, mocked_post):
        """Check sadness as the dominant emotion."""
        mocked_post.return_value = self._watson_response("sadness")
        self.assertEqual(
            emotion_detector("I feel very sad.")["dominant_emotion"], "sadness"
        )

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_anger(self, mocked_post):
        """Check anger as the dominant emotion."""
        mocked_post.return_value = self._watson_response("anger")
        self.assertEqual(
            emotion_detector("I hate working long hours.")["dominant_emotion"],
            "anger",
        )

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_fear(self, mocked_post):
        """Check fear as the dominant emotion."""
        mocked_post.return_value = self._watson_response("fear")
        self.assertEqual(
            emotion_detector("I am scared.")["dominant_emotion"], "fear"
        )

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_disgust(self, mocked_post):
        """Check disgust as the dominant emotion."""
        mocked_post.return_value = self._watson_response("disgust")
        self.assertEqual(
            emotion_detector("That is revolting.")["dominant_emotion"],
            "disgust",
        )

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_http_400(self, mocked_post):
        """HTTP 400 returns the expected empty result."""
        mocked_post.return_value.status_code = 400
        result = emotion_detector("bad request")
        self.assertIsNone(result["dominant_emotion"])
        self.assertTrue(all(value is None for value in result.values()))

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_empty_input_does_not_call_watson(self, mocked_post):
        """Blank input is handled before the network request."""
        result = emotion_detector("  ")
        self.assertIsNone(result["dominant_emotion"])
        mocked_post.assert_not_called()


if __name__ == "__main__":
    unittest.main()
