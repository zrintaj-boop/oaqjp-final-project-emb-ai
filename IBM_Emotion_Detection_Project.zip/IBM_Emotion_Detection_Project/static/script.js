"use strict";

async function runEmotionDetection() {
  const text = document.getElementById("textToAnalyze").value;
  const output = document.getElementById("system_response");
  if (!text.trim()) {
    output.textContent = "Invalid text! Please try again!";
    return;
  }
  output.textContent = "Analyzing...";
  try {
    const response = await fetch(
      "/emotionDetector?textToAnalyze=" + encodeURIComponent(text)
    );
    const message = await response.text();
    output.textContent = message;
  } catch (error) {
    output.textContent = "The analysis service is unavailable. Please try again.";
  }
}

document.getElementById("analyze").addEventListener("click", runEmotionDetection);
