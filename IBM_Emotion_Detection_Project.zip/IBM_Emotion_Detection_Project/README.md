# Emotion Detection using IBM Watson NLP

Final project for the IBM AI Developer program. This Flask web application
accepts English customer feedback and returns scores for **anger**, **disgust**,
**fear**, **joy**, and **sadness**, plus the **dominant emotion**.

## Project files

- `EmotionDetection/emotion_detection.py` — calls IBM Watson NLP EmotionPredict
- `EmotionDetection/__init__.py` — exports `emotion_detector`
- `server.py` — Flask routes and input validation
- `templates/index.html` — web interface
- `static/` — interface styles and JavaScript
- `test_emotion_detection.py` — automated unit tests (mock Watson responses)

## Setup

```bash
python3 -m pip install -r requirements.txt
```

## Run the app

```bash
python3 server.py
```

Open `http://localhost:5000/` or use the forwarded port in the Skills Network Cloud IDE.

Try the phrase `I think I am having fun` and click **Analyze emotions**.
Try an empty input to verify the error message `Invalid text! Please try again!`.

## Run tests

```bash
python3 -m unittest -v test_emotion_detection.py
```

## Static code analysis

```bash
python3 -m pylint EmotionDetection server.py test_emotion_detection.py
```

## Important notes

- This app depends on the IBM Skills Network Watson EmotionPredict service. Its
  URL and availability are controlled by IBM; a live response requires network
  access and a working service endpoint.
- Unit tests use **mocked API responses** so they do not prove that the live
  Watson endpoint is currently accessible.
- The project is original example code aligned to the provided assignment
  outline, not a verified copy of the lab's starter repository.
- For graded screenshot questions, capture the **real running app** and the
  **actual terminal output**; do not substitute example images.
